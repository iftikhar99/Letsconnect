=== Financey ===
Contributors: Themeansar
Tags: three-columns, left-sidebar, right-sidebar, custom-colors, custom-logo, featured-images, full-width-template, threaded-comments, blog, e-commerce, entertainment
Requires at least: 4.0.5
Tested up to: 5.7
Requires PHP: 7.0
Stable tag: 0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple WordPress theme designed for agency and businesses.

== Description ==
Financey WordPress theme ideal for a business or blog website (corporate, Consulting, Advisor, Agency, Finance, law, Photography, freelancers, online presence etc.). You can also use for anything. It comes with all features these kind of Google Fonts, logo upload, slider, service, blog, shop page and much more. The theme you can use for any business website.Work with the most popular page builders as SiteOrigin. Developers will love his extensible codebase making it a joy to customize and extend. Looking for a Multi-Purpose theme? Look no further! Check the demos to realize that it's the only theme you will ever need: https://demo.themeansar.com/agencyup/


Financey WordPress Theme, Copyright 2021 Themeansar
Financey is distributed under the terms of the GNU GPL

Agencyup WordPress Theme is child theme of Financey WordPress Theme, Copyright 2021 Themeansar
Financey WordPress Theme is distributed under the terms of the GNU GPL



== Frequently Asked Questions ==

= Does this theme support any plugins? =

Yes. Theme supports SiteOrigin Page Builder and Contact Form 7.

== Changelog ==

--- Version 0.1 ----
1. Released

--- Version 0.2 ----
1. Fixed Theme review issue.

--- Version 0.2 ----
1. Update Theme URI.

== Screenshots ==
============================================
***** Screenshot image CCO by pxhere *****/
1. https://pxhere.com/en/photo/1453379